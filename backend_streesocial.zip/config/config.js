// config.js
const config = {
   
    apiUrl: 'http://192.168.0.113:3000', // Adjust the port accordingly
  };
  
  
  module.exports = config;